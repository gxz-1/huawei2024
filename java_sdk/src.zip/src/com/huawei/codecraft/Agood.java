package com.huawei.codecraft;

class Agood {
    int x;
    int y;
    int val;

    public Agood(int x, int y, int val) {
        this.x = x;
        this.y = y;
        this.val = val;
    }

}
